package com.aliee.quei.mo.config

import com.aliee.quei.mo.data.bean.PayWayBean

object  PayWayConfig{
    var payWayList = listOf<PayWayBean>()
}