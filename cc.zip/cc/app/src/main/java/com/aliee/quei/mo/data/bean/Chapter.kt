package com.aliee.quei.mo.data.bean

data class CatalogListBean(
    val cChapterList : List<CatalogItemBean>,
    val count : Int
)
