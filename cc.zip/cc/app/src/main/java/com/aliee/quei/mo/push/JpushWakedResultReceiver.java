package com.aliee.quei.mo.push;

/*
import cn.jpush.android.service.WakedResultReceiver;
*/

/**
 * 作者:sunfuyi
 * 时间:2019-08-07PushMessageReceiver
 * 描述:
 */
/*public class JpushWakedResultReceiver extends WakedResultReceiver {
}*/
