package com.aliee.quei.mo.data.bean

data class TempUser(
    val istemp: Int,
    val servertoken: String,
    val tname: String
)