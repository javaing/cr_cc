package com.aliee.quei.mo.data.bean;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class VideoDomain {

    @SerializedName("20")
    private List<Domain> domains;


    public static class Domain {

    }
}
