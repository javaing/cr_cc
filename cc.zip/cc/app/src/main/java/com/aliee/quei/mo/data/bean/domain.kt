package com.aliee.quei.mo.data.bean

data class DomainBean(
        val domain: String,
        val enable: Int,
        val hotfix: Int,
        val cs_route: String,
        val backup_oss: Object?

)