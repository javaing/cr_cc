package com.aliee.quei.mo.data.bean

class AutoPlayConf {
    var enable: Int = 1
    var count: Int = 5
    override fun toString(): String {
        return "AutoPlayConf(enable=$enable, count=$count)"
    }

}