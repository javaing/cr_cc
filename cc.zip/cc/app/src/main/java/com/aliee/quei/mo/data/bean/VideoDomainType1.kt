package com.aliee.quei.mo.data.bean

import com.google.gson.annotations.SerializedName

data class VideoDomainType1(
    @SerializedName("1")
    val `1`: List<Domain>
)
