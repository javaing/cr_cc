package com.aliee.quei.mo.data.bean

data class VideoAuth(val servertoken:String,val istemp:Int,val tname:String)