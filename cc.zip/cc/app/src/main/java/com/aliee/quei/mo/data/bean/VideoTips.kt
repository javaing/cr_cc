package com.aliee.quei.mo.data.bean

data class VideoTips(
    val bookbean: Bookbean,
    val freetime: Freetime
)

