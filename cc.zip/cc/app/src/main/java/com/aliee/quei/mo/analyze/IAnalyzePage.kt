package com.aliee.quei.mo.analyze

/**
 * Created by liyang on 2018/6/8 0008.
 */
interface IAnalyzePage{
    fun getPageName () : String?
}