package com.aliee.quei.mo.push;

/*import cn.jpush.android.service.JCommonService;*/


/*public class JpushService extends JCommonService {
}*/
