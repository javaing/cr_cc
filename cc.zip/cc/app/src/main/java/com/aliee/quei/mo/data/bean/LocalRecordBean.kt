package com.aliee.quei.mo.data.bean

data class LocalRecordBean(
    val bookid : Int,
    val bookName : String,
    val chapterId : Int,
    val chapterName : String
)