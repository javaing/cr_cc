package com.aliee.quei.mo.data.bean

class VideoPreview {
    val video_previewpath:String=""
}