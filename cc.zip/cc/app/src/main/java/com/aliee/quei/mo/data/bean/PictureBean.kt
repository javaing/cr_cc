package com.aliee.quei.mo.data.bean

data class PictureBean (
    val url : String? = null
)