package com.aliee.quei.mo.config

import android.util.Log

fun String.e(str:String){
    Log.e("LOG",str)
}