package com.aliee.quei.mo.data.bean

/**
 * Created by Administrator on 2018/4/28 0028.
 */

data class CategoryBean(
    val id : Int,
    val typename : String
)
