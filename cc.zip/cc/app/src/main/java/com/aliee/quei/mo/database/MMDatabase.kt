package com.aliee.quei.mo.database

/**
 * @Author: YangYang
 * @Date: 2017/12/26
 * @Version: 1.0.0
 * @Description:
 */
object MMDatabase {
    val DATABASE_NAME = "comic.realm"
    val DATABASE_VERSION = 3L
}