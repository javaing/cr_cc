package com.aliee.quei.mo.data.bean

data class CoinsAmountBean(
    val bean : Int = 0
)