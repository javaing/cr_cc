package com.aliee.quei.mo.data.bean
data class AdZoneBean(
    val adStatus: Int,
    val zoneId: Int
)