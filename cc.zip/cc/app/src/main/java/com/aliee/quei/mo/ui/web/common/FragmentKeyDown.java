package com.aliee.quei.mo.ui.web.common;

import android.view.KeyEvent;

/**
 * Created by cenxiaozhong on 2017/5/23.
 * source code  https://github.com/Justson/AgentWeb
 */

public interface FragmentKeyDown {

    boolean onFragmentKeyDown(int keyCode, KeyEvent event);
}
