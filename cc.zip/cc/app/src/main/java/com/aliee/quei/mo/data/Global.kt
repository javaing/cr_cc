package com.aliee.quei.mo.data

object Global : HashMap<String, String>(){
    const val KEY_TRADE_NO = "out_trade_no"
    const val KEY_HAS_OPEN_H5_PAY = "key_has_open_h5_key"
}