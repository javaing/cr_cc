package com.aliee.quei.mo.data.bean

data class BillRecordBean(
    val bookBean: Int?,
    val bookid: Int?,
    val chapeterid: Int?,
    val surplusBookBean: Int?,
    val time: Long?,
    val bookName : String?,
    val chapeterName : String?
)

